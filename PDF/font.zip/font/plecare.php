<?php
$type='Type1';
$name='PLECare';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>388,'Flags'=>32,'FontBBox'=>'[-414 -302 717 893]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>242,'!'=>156,'"'=>191,'#'=>441,'$'=>402,'%'=>426,'&'=>353,'\''=>131,'('=>154,')'=>270,'*'=>284,'+'=>247,
	','=>231,'-'=>316,'.'=>182,'/'=>286,'0'=>309,'1'=>234,'2'=>388,'3'=>345,'4'=>342,'5'=>439,'6'=>257,'7'=>289,'8'=>291,'9'=>297,':'=>201,';'=>198,'<'=>242,'='=>322,'>'=>242,'?'=>242,'@'=>409,'A'=>1000,
	'B'=>1000,'C'=>350,'D'=>1000,'E'=>286,'F'=>1000,'G'=>1000,'H'=>1000,'I'=>1000,'J'=>1000,'K'=>1000,'L'=>318,'M'=>1000,'N'=>1000,'O'=>1000,'P'=>290,'Q'=>1000,'R'=>1000,'S'=>1000,'T'=>1000,'U'=>1000,'V'=>1000,'W'=>1000,
	'X'=>1000,'Y'=>1000,'Z'=>1000,'['=>1000,'\\'=>1000,']'=>1000,'^'=>1000,'_'=>1000,'`'=>1000,'a'=>298,'b'=>1000,'c'=>1000,'d'=>1000,'e'=>304,'f'=>1000,'g'=>1000,'h'=>1000,'i'=>390,'j'=>1000,'k'=>415,'l'=>1000,'m'=>1000,
	'n'=>1000,'o'=>1000,'p'=>1000,'q'=>290,'r'=>277,'s'=>1000,'t'=>1000,'u'=>471,'v'=>1000,'w'=>1000,'x'=>1000,'y'=>1000,'z'=>1000,'{'=>242,'|'=>242,'}'=>242,'~'=>242,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>242,chr(161)=>427,chr(162)=>341,chr(163)=>444,chr(164)=>385,chr(165)=>407,chr(166)=>495,chr(167)=>256,chr(168)=>312,chr(169)=>472,chr(170)=>363,chr(171)=>427,chr(172)=>652,chr(173)=>617,chr(174)=>409,chr(175)=>425,
	chr(176)=>337,chr(177)=>521,chr(178)=>575,chr(179)=>572,chr(180)=>381,chr(181)=>411,chr(182)=>439,chr(183)=>471,chr(184)=>278,chr(185)=>432,chr(186)=>499,chr(187)=>390,chr(188)=>432,chr(189)=>400,chr(190)=>485,chr(191)=>488,chr(192)=>395,chr(193)=>468,chr(194)=>390,chr(195)=>296,chr(196)=>390,chr(197)=>343,
	chr(198)=>381,chr(199)=>292,chr(200)=>445,chr(201)=>551,chr(202)=>358,chr(203)=>497,chr(204)=>482,chr(205)=>303,chr(206)=>334,chr(207)=>403,chr(208)=>306,chr(209)=>0,chr(210)=>274,chr(211)=>281,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>242,chr(224)=>238,chr(225)=>430,chr(226)=>254,chr(227)=>296,chr(228)=>290,chr(229)=>263,chr(230)=>415,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>281,chr(240)=>319,chr(241)=>428,
	chr(242)=>511,chr(243)=>411,chr(244)=>505,chr(245)=>473,chr(246)=>495,chr(247)=>523,chr(248)=>542,chr(249)=>460,chr(250)=>522,chr(251)=>723,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='plecare.z';
$size1=6095;
$size2=25410;
?>
