<?php
$type='Type1';
$name='PLEJoy';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>473,'Flags'=>32,'FontBBox'=>'[-401 -313 617 981]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>136,'!'=>117,'"'=>171,'#'=>548,'$'=>261,'%'=>380,'&'=>366,'\''=>120,'('=>132,')'=>181,'*'=>249,'+'=>264,
	','=>155,'-'=>262,'.'=>145,'/'=>207,'0'=>311,'1'=>231,'2'=>244,'3'=>289,'4'=>384,'5'=>311,'6'=>284,'7'=>331,'8'=>285,'9'=>335,':'=>143,';'=>161,'<'=>301,'='=>253,'>'=>264,'?'=>260,'@'=>498,'A'=>513,
	'B'=>317,'C'=>350,'D'=>314,'E'=>286,'F'=>258,'G'=>357,'H'=>386,'I'=>135,'J'=>263,'K'=>349,'L'=>318,'M'=>462,'N'=>415,'O'=>418,'P'=>290,'Q'=>420,'R'=>409,'S'=>338,'T'=>320,'U'=>399,'V'=>441,'W'=>654,
	'X'=>513,'Y'=>349,'Z'=>473,'['=>205,'\\'=>278,']'=>253,'^'=>267,'_'=>401,'`'=>157,'a'=>298,'b'=>252,'c'=>227,'d'=>272,'e'=>304,'f'=>192,'g'=>300,'h'=>282,'i'=>123,'j'=>250,'k'=>280,'l'=>124,'m'=>344,
	'n'=>271,'o'=>276,'p'=>294,'q'=>286,'r'=>277,'s'=>270,'t'=>283,'u'=>327,'v'=>363,'w'=>491,'x'=>334,'y'=>324,'z'=>338,'{'=>265,'|'=>125,'}'=>274,'~'=>446,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>136,chr(161)=>321,chr(162)=>300,chr(163)=>346,chr(164)=>352,chr(165)=>369,chr(166)=>362,chr(167)=>234,chr(168)=>333,chr(169)=>393,chr(170)=>241,chr(171)=>285,chr(172)=>438,chr(173)=>413,chr(174)=>329,chr(175)=>350,
	chr(176)=>275,chr(177)=>395,chr(178)=>419,chr(179)=>459,chr(180)=>359,chr(181)=>372,chr(182)=>294,chr(183)=>375,chr(184)=>233,chr(185)=>380,chr(186)=>362,chr(187)=>357,chr(188)=>337,chr(189)=>289,chr(190)=>363,chr(191)=>342,chr(192)=>343,chr(193)=>317,chr(194)=>323,chr(195)=>240,chr(196)=>293,chr(197)=>338,
	chr(198)=>343,chr(199)=>266,chr(200)=>251,chr(201)=>369,chr(202)=>249,chr(203)=>358,chr(204)=>376,chr(205)=>329,chr(206)=>279,chr(207)=>298,chr(208)=>235,chr(209)=>0,chr(210)=>206,chr(211)=>184,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>286,chr(224)=>162,chr(225)=>239,chr(226)=>212,chr(227)=>238,chr(228)=>285,chr(229)=>206,chr(230)=>229,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>277,chr(240)=>338,chr(241)=>309,
	chr(242)=>381,chr(243)=>421,chr(244)=>329,chr(245)=>354,chr(246)=>245,chr(247)=>499,chr(248)=>362,chr(249)=>392,chr(250)=>355,chr(251)=>625,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='plejoy.z';
$size1=6090;
$size2=35918;
?>
